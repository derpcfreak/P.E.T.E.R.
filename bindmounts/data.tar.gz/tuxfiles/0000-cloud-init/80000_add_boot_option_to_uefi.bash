#!/bin/bash
###################################################################################
# 8000_add_boot_option_to_uefi.bash
###################################################################################
# Creates and configures UEFI boot entry to automatically launch Windows setup
# from the EFI System Partition at next reboot. Finalizes the automated Windows
# installation preparation process.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Identifies target disk using helper script with safety checks
#   4. Determines partition naming convention (p1-p4 vs 1-4)
#   5. Installs efibootmgr package from Ubuntu Live ISO (/cdrom)
#   6. Creates mount directories: /mnt/p1, /mnt/p4, /mnt/wim
#   7. Mounts partitions:
#      - p1: EFI System Partition (contains Windows bootloader)
#      - p4: Recovery partition (contains extracted Windows ISO files)
#   8. Deletes any previous "P.E.T.E.R." boot entry (for idempotency)
#   9. Creates new UEFI boot entry:
#      - Label: "P.E.T.E.R."
#      - Target: ${diskdev} partition 1
#      - Loader: \EFI\Boot\bootx64.efi
#      - Sets as default boot option
#   10. Displays current UEFI boot configuration
#   11. Syncs filesystem and unmounts all partitions
#
# Result: On next boot, system will automatically execute Windows Setup using
# autounattend.xml and installation files prepared by previous scripts.
#
# Exit strategy: Enters infinite sleep if target disk cannot be identified.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash
me=$(basename "$0")

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi
# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

# install efibootmgr from /cdrom
dpkg -i "$(find /cdrom/ -iname "efibootmgr*.deb")"

# create mount directories
mkdir /mnt/p1 2>/dev/null
mkdir /mnt/p4 2>/dev/null
mkdir /mnt/wim 2>/dev/null

# mount p1 to /mnt/p1
mount "${diskdev}${prefix}1" /mnt/p1

# mount p4 to /mnt/p4
mount "${diskdev}${prefix}4" /mnt/p4

# delete (if exists) previous boot entry of ours
efibootmgr --delete-bootnum -L "P.E.T.E.R." >/dev/null 2>&1

# create boot entry in EFI for <p1>\EFI\Boot\bootx64.efi and set it as default
efibootmgr --quiet --create --label "P.E.T.E.R." --disk "${diskdev}" --part 1 --loader "\EFI\Boot\bootx64.efi"

# show result
echo -e "\n"
efibootmgr
echo -e "\n"
# sync file system operations
sync

# unmount /mnt/p1
umount /mnt/p1
# unmount /mnt/p3
umount /mnt/p3
# unmount /mnt/p4
umount /mnt/p4
