#!/bin/bash
# -----------------------------------------------------------------------------
# Script Name: Z0_identify_target_block_device.bash
#
# Description:
# Identifies a single physical block device on the system for use by other scripts.
# Behavior:
#   - spits out the FIRST real disk found and prints its path (e.g., /dev/nvme0n1)
# This version filters out:
#   - optical drives (sr*)
#   - loop devices (loop*)
#   - RAM disks (ram*)
#   - non-physical or virtual devices (no /sys/block/<dev>/device)
# -----------------------------------------------------------------------------

# source variables.config just in case
source ./variables.config

# List all real, non-USB, non-removable whole disks suitable for OS installation
# Sorted by size (largest first), output without quotes

command -v lshw >/dev/null 2>&1 || { echo "lshw not found"; exit 1; }
command -v jq >/dev/null 2>&1 || { echo "jq not found"; exit 1; }

disk=$(lsblk -dn -o NAME,SIZE,TYPE,TRAN | \
  awk '$3=="disk" && $4!="usb" && $1 !~ /^(sr|loop|ram|dm-)/ {print "/dev/"$1,$2}' | sort -k2 -h | tail -n 1 | cut -d' ' -f1)
echo "$disk"
