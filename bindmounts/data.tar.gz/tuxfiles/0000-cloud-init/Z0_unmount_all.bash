#!/bin/bash
# Helper script to quickly mount partitions p3 and p4 on a live system.
# Detects the single NVMe or block device, then mounts its p3 and p4 partitions
# to /mnt/p3 and /mnt/p4 for troubleshooting or SSH access.
# Does not modify or copy any files; purely for inspection and convenience.
# variables in CAPITALS are sourced from ./variables.config


# source variables from variables.config
source ./variables.config
me=$(basename "$0")
echo -e "${LIGHTBLUE}running ${me}${NC}" | tee "${TTY}"

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi

# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

if [ ! -z ${diskdev+x} ] # if diskdev is set
then
	curr="$PWD"
	cd /tmp || exit
        echo -n "unmounting all ..."
        umount -f "${diskdev}${prefix}1" 2>/dev/null
        umount -f "${diskdev}${prefix}2" 2>/dev/null
        umount -f "${diskdev}${prefix}3" 2>/dev/null
        umount -f "${diskdev}${prefix}4" 2>/dev/null
        umount -f "/mnt/wim" 2>/dev/null
        wimunmount -f "/mnt/wim" 2>/dev/null
        umount -f "/mnt/isomount" 2>/dev/null
        echo "done."
	cd "$curr" || exit
fi
