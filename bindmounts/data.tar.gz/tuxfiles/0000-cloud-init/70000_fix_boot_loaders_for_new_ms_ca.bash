#!/bin/bash
###################################################################################
# 7000_fix_boot_loaders_for_new_ms_ca.bash
###################################################################################
# Detects and updates Windows boot loaders for systems with Windows UEFI CA 2023
# certificate. Mimics Microsoft's 'Make2023BootableMedia.ps1' script to ensure
# installation media is compatible with newer Secure Boot requirements.
#
# Background:
# Microsoft introduced Windows UEFI CA 2023 as a new certificate authority for
# Secure Boot. Systems with this certificate require updated boot loaders (_EX versions)
# to boot Windows installation media. This script automates the boot file replacement
# process documented in Microsoft's secureboot_objects repository.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Identifies target disk using helper script with safety checks
#   4. Determines partition naming convention (p1-p4 vs 1-4)
#   5. Mounts p4 (recovery partition containing extracted Windows ISO)
#   6. Checks BIOS firmware for 'Windows UEFI CA 2023' certificate using efi-readvar
#   7. If certificate found:
#      a. Mounts boot.wim (index 2) from /mnt/p4/sources/ to /mnt/wim
#      b. Extracts _EX boot loader files from mounted WIM:
#         - bootmgr_EX.efi → /mnt/p4/bootmgr.efi
#         - bootmgfw_EX.efi → /mnt/p4/efi/boot/bootx64.efi
#         - efisys_EX.bin → /mnt/p4/efi/microsoft/boot/efisys.bin
#         - Fonts_EX/*.ttf → /mnt/p4/efi/microsoft/boot/fonts/ (renamed without _EX)
#      c. Unmounts boot.wim
#   8. If certificate NOT found: skips boot file updates (standard files work)
#   9. Syncs filesystem and unmounts p4
#
# Reference: https://github.com/microsoft/secureboot_objects
#
# Exit strategy: Enters infinite sleep if target disk cannot be identified.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi
# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

### NOW IT BEGINS

# create mount directories
mkdir /mnt/p4 2>/dev/null

# mount p4 to /mnt/p4
mount "${diskdev}${prefix}4" /mnt/p4

###################################################################################################
# CODE TO FIX BOOT ENVIRONMENT FOR Windows UEFI CA 2023
#  find out if BIOS already has the Windows UEFI CA 2023
#  If so we can (and should) mimic the procedures from
#  Microsoft Powershell Script 'Make2023BootableMedia.ps1'
#  (https://github.com/microsoft/secureboot_objects)
#  check if efi-readvar command is installed
#echo -n "checking BIOS for 'Windows UEFI CA 2023'..." > "${TTY}"
if (efi-readvar -v db | grep -q 'Windows UEFI CA 2023')
then
 echo "found!"
 echo -e "${LIGHTGREEN}mimic 'Make2023BootableMedia.ps1' to change boot loaders for 'Windows UEFI CA 2023'${NC}"
 isofilesfolder=/mnt/p4
 wimmountpath=/mnt/wim
 targetfolder=/mnt/p4 # extracted windows.iso
 # mount index 1 of boot.wim
 wimmount "${isofilesfolder}/sources/boot.wim" 2 "${wimmountpath}"
 # define variables for our actions
 ex_bins_path=/mnt/wim/Windows/Boot/EFI_EX
 ex_fonts_path=/mnt/wim/Windows/Boot/Fonts_EX
 ex_dvd_path=/mnt/wim/Windows/Boot/DVD_EX
 # copy files
 echo cp "${ex_bins_path}/bootmgr_EX.efi" "${targetfolder}/bootmgr.efi"
 cp "${ex_bins_path}/bootmgr_EX.efi" "${targetfolder}/bootmgr.efi"
 echo cp "${ex_bins_path}/bootmgfw_EX.efi" "${targetfolder}/efi/boot/bootx64.efi"
 cp "${ex_bins_path}/bootmgfw_EX.efi" "${targetfolder}/efi/boot/bootx64.efi"
 echo cp "${ex_dvd_path}/EFI/en-US/efisys_EX.bin" "${targetfolder}/efi/microsoft/boot/efisys_ex.bin"
 cp "${ex_dvd_path}/EFI/en-US/efisys_EX.bin" "${targetfolder}/efi/microsoft/boot/efisys_ex.bin"
 mkdir "${targetfolder}/efi/microsoft/boot/fonts_ex/"
 echo cp "${ex_fonts_path}"/* "${targetfolder}/efi/microsoft/boot/fonts_ex/"
 cp "${ex_fonts_path}"/* "${targetfolder}/efi/microsoft/boot/fonts_ex/"
 # rename files in fonts_ex
 for font in "${targetfolder}/efi/microsoft/boot/fonts_ex/"*_EX.ttf
  do
#  newname=$(sed "s/_EX//" <<< "${font}")
# shellcheck safe version of the above
  newname="${font//_EX/}"
  echo moving/renaming "${font}" to "${newname}"
  mv "${font}" "${newname}"
 done
 # move fonts_ex fonts to fonts
 mv "${targetfolder}/efi/microsoft/boot/fonts_ex/"* "${targetfolder}/efi/microsoft/boot/fonts/"
 # remove fonts_ex folder
 rm -r -f -- "${targetfolder}/efi/microsoft/boot/fonts_ex/"
 #unmount wim
 umount ${wimmountpath}
else
 echo "NOT FOUND!"
 echo -e "${LIGHTGREEN}Will NOT change boot files for 'Windows UEFI CA 2023'${NC}"
 echo ""
fi
###################################################################################################

# sync file system operations
sync
# unmount /mnt/p4
umount /mnt/p4
