#!/bin/bash
###################################################################################
# 6000_download_and_extract_windows_iso.bash
###################################################################################
# Downloads Windows ISO and autounattend.xml, extracts ISO contents to recovery
# partition (p4), and prepares the disk for automated Windows installation.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Unmounts any mounted WIM files and /mnt/ mountpoints (for idempotency)
#   4. Identifies target disk using helper script with safety checks
#   5. Determines partition naming convention (p1-p4 vs 1-4)
#   6. Creates mount directories: /mnt/isomount, /mnt/p1, /mnt/p3, /mnt/p4
#   7. Mounts partitions:
#      - p1: EFI partition (mounted but not actively used in this script)
#      - p3: Large data partition for temporary ISO storage
#      - p4: Recovery partition for extracted ISO files
#   8. Downloads autounattend.xml from ${XMLURL} to /mnt/p4
#   9. Downloads Windows ISO from ${WINISOURL} to /mnt/p3/windows.iso
#   10. Mounts Windows ISO to /mnt/isomount
#   11. Copies all ISO contents to /mnt/p4 (recovery partition)
#   12. Unmounts ISO and deletes windows.iso to free space
#   13. Syncs filesystem and unmounts all partitions
#
# Partition usage:
#   - p3: Temporary storage for windows.iso (deleted after extraction)
#   - p4: Final location for extracted Windows installation files + autounattend.xml
#
# WARNING: Total size of ISO contents + autounattend.xml must fit in p4.
#          Adjust P4SIZE in variables.config if needed.
#
# Exit strategy: Enters infinite sleep if target disk cannot be identified.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash

# unmount all possibly mounted wim files (to ensure this script can also be executed manually)
mount | grep 'type fuse.wimfs' | awk '{print $3}' | while read -r mountpoint; do
    echo "Unmounting: $mountpoint"
    wimunmount "$mountpoint" 2>/dev/null
done

# unmount all possible mountpoints (to ensure this script can also be executed manually)
mount | grep ' /mnt/' | awk '{print $3}' | sort -r | while read -r mountpoint; do
    echo "Unmounting: $mountpoint"
    umount -f -l "$mountpoint"
done

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi
# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

### NOW IT BEGINS

# create mount directories
mkdir /mnt/isomount 2>/dev/null
mkdir /mnt/p1 2>/dev/null
mkdir /mnt/p3 2>/dev/null
mkdir /mnt/p4 2>/dev/null

# mount p1 to /mnt/p1
mount "${diskdev}${prefix}1" /mnt/p1

# mount p3 to /mnt/p3
mount "${diskdev}${prefix}3" /mnt/p3

# mount p4 to /mnt/p4
mount "${diskdev}${prefix}4" /mnt/p4

# download autounattended.xml to /mnt/p4
echo "Downloading unattended.xml to /mnt/p4"
wget -o - --show-progress "${XMLURL}" -O /mnt/p4/autounattend.xml

# download windows ISO as windows.iso to /mnt/p3
echo "Downloading windows.iso"
wget -o - --show-progress "${WINISOURL}" -O /mnt/p3/windows.iso

# mount windows ISO to /mnt/isomount
mount /mnt/p3/windows.iso /mnt/isomount

# copy all files from ISO to /mnt/p4
echo "copying ISO files to /mnt/p4"
cp -Rv /mnt/isomount/* /mnt/p4

# sync file system operations
sync

# unmount /mnt/isomount
umount /mnt/isomount

# delete ISO
echo "Deleting windows.iso"
rm -f /mnt/p3/windows.iso

# sync file system operations
sync

# unmount /mnt/p1
umount /mnt/p1
# unmount /mnt/p3
umount /mnt/p3
# unmount /mnt/p4
umount /mnt/p4
