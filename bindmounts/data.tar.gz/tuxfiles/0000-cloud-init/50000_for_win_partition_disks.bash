#!/bin/bash
###################################################################################
# for_win_partition_disks.bash
###################################################################################
# Prepares a target disk for Windows installation with proper GPT partition layout.
# 
# Operations performed:
#   1. Loads partition size variables from ./variables.config
#   2. Displays progress image on screen
#   3. Unmounts any mounted WIM files and /mnt/ mountpoints
#   4. Identifies target disk using helper script with safety checks
#   5. Determines partition naming convention (p1-p4 vs 1-4 based on disk name)
#   6. Wipes disk signatures and zeros beginning of disk
#   7. Creates 4 GPT partitions:
#      - p1: EFI System Partition (size: P1SIZE)
#      - p2: Microsoft Reserved Partition (size: P2SIZE, unformatted)
#      - p3: Basic Data Partition for Windows C: drive (size: P3SIZE)
#      - p4: Recovery/ISO Storage Partition (remaining space)
#   8. Formats p1 as FAT32, p3 and p4 as NTFS
#   9. Reloads partition table and syncs filesystem operations
#
# DESTRUCTIVE: Erases all data on target disk. Ensures correct disk identification.
# Exit strategy: Enters infinite sleep if target disk cannot be identified.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
# to get
#    P1SIZE (size of partition 1 (EFI)
#    P2SIZE (size of partition 2 (Microsoft reserved)
#    P3SIZE (size of partition 3 (Basic data partition -> Future C: drive)
#    P4SIZE (size of partition 4 (Microsoft recovery partition)
source ./variables.config

# show an image on screen
/dev/shm/Z0_show_image_per_script.bash

# unmount all possibly mounted wim files (to ensure this script can also be executed manually)
mount | grep 'type fuse.wimfs' | awk '{print $3}' | while read -r mountpoint; do
    echo "Unmounting: $mountpoint"
    wimunmount "$mountpoint" 2>/dev/null
done

# unmount all possible mountpoints (to ensure this script can also be executed manually)
mount | grep ' /mnt/' | awk '{print $3}' | sort -r | while read -r mountpoint; do
    echo "Unmounting: $mountpoint"
    umount -f -l "$mountpoint"
done

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi

# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"


# PARTITIONING THE DISK
#echo "Partitioning target disk ${diskdev}" | tee "${TTY}"
echo "Partitioning target disk ${diskdev}"

## WIPE
wipefs -a "${diskdev}" # recommended if you want to swap partition table types
# or sgdisk --zap-all ${diskdev}

# for sure throw some zeros to the beginning of the disk
dd if=/dev/zero of="${diskdev}" bs=4096 count=10

## p1 P1SIZE EFI system partition
sgdisk --new=1::${P1SIZE} "${diskdev}"
sgdisk --typecode=1:C12A7328-F81F-11D2-BA4B-00A0C93EC93B "${diskdev}"

## p2 P2SIZE Microsoft reserved partition
sgdisk --new=2::${P2SIZE} "${diskdev}"
sgdisk --typecode=2:E3C9E316-0B5C-4DB8-817D-F92DF00215AE "${diskdev}"

## p3 -P3SIZE from end of disk as Basic data partition (must be able to hold windows iso + extracted files)
sgdisk --new=3::${P3SIZE} "${diskdev}"
sgdisk --typecode=3:EBD0A0A2-B9E5-4433-87C0-68B6B72699C7 "${diskdev}"

## p4 REST Windows recovery environment (will also hold windows ISO and our setup files)
sgdisk --new=4:: "${diskdev}"
sgdisk --typecode=4:2700 "${diskdev}"

## reload partition table
partprobe "${diskdev}"

# FORMAT DISKS
echo "Formatting partitions on ${diskdev} (p1-p4)"

## format p1 with FAT32/VFAT and volume name EFI
mkfs.vfat -n "EFI" "${diskdev}${prefix}1"

## format p3 with NTFS with label WINDOWS
mkfs.ntfs -f -L "WINDOWS" "${diskdev}${prefix}3"

## format p4 with NTFS
mkfs.ntfs -f "${diskdev}${prefix}4"

## sync file system operations
sync
