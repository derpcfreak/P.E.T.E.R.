#!/bin/bash
###################################################################################
# 1000_kernel_parameters_to_config.bash
###################################################################################
# Allows runtime override of variables.config settings via kernel command line.
# Designed for cloud-init environments to customize deployments without modifying
# the configuration file directly.
#
# Operations performed:
#   1. Sources existing configuration from ./variables.config
#   2. Reads kernel command line from /proc/cmdline
#   3. Extracts content after '---' marker
#   4. Parses ADDITIONAL parameter value (format: key1=val1#key2=val2#...)
#   5. Splits ADDITIONAL on '#' delimiter to separate multiple overrides
#   6. Appends each non-empty override to variables.config with marker comment
#   7. Restores original IFS (Internal Field Separator)
#
# Input format in grub.cfg:
#   <normal params> --- ADDITIONAL='VAR1="value1"#VAR2="value2"'
#
# Output in variables.config:
#   # OVERRIDE from /proc/cmdline
#   VAR1="value1"
#   # OVERRIDE from /proc/cmdline
#   VAR2="value2"
#
# Each override is appended with a comment in variables.config to indicate it
# came from the kernel command line.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
#additional=$(cat /proc/cmdline | sed 's@.*\-\-\-\s*@@g' | sed 's@^ADDITIONAL=\(.*\)@\1@g'| sed 's@\\"@\"@g')
additional=$(sed 's@.*\-\-\-\s*@@g' </proc/cmdline | sed 's@^ADDITIONAL=\(.*\)@\1@g'| sed 's@\\"@\"@g')

# Save the original IFS (Internal Field Separator)
OLDIFS="$IFS"

# Split the ADDITIONAL string on '#' to handle multiple overrides
IFS='#'

# Append each override to variables.config with a comment
for override in $additional
do
 # add override with comment
 if [ ! "$override" == "" ]; then
  echo '# OVERRIDE from /proc/cmdline' >> ./variables.config
  echo "$override" >> ./variables.config
 fi
done

# Restore the original IFS
IFS="$OLDIFS"
