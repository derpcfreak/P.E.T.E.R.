#!/bin/bash

source /dev/shm/variables.config
printf '\e[0m\e[H\e[2J' > "${TTY}"
# hide cursor
printf '\e[?25l' > "${TTY}"
# show cursor
#printf '\e[?25h' > "${TTY}"

# detect which script called us
full_parent=$(ps -o args= $PPID)
parent_script=$(basename "$(echo "$full_parent" | awk '{print $2}')")


# get screen resolution for fb0
fbwidth=$(cat /sys/class/graphics/fb0/virtual_size|awk -F ',' '{print $1}')
fbheight=$(cat /sys/class/graphics/fb0/virtual_size|awk -F ',' '{print $2}')

# We assume that our images are 1920x1080, so we have to calculate the offset
# if the height or width exceeds those boundaries
if [ "$fbwidth" -gt 1920 ]
then
        xoffset=$(( (fbwidth - 1920)/2))
else
        xoffset=0
fi

if [ "$fbheight" -gt 1080 ]
then
        yoffset=$(( (fbheight - 1080)/2))
else
        yoffset=0
fi

# create image filename based on calling script
# e.g. 'test.bash' will become 'test.png'
image="$(basename "$parent_script" .bash).png" 2>/dev/null
if [[ -f "/dev/shm/images/$image" ]]
then
 if [[ -f "/dev/shm/images/imgfb" ]] # if imgfb binary exists
 then
  echo -n "showing image $image on screen.."
  /dev/shm/images/imgfb "/dev/shm/images/$image" -f fb0 -x $xoffset -y $yoffset # call imgfb binary
  echo "done"
  # show image at least for 5 seconds
  echo -n "sleeping 5 seconds..."
  sleep 5
  echo "done"
 fi
fi
