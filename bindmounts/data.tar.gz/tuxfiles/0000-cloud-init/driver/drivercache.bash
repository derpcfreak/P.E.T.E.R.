#!/bin/bash
#
# variables in CAPITALS are sourced from ./variables.config
# source variables from variables.config
source ../variables.config

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | sudo tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi

# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"


# make sure /mnt/p3 exists
mkdir /mnt/p3 2>/dev/null

# mount /mnt/p3 as temporary storage
mount "${diskdev}${prefix}3" /mnt/p3

# when final read the below variables from variables.config
# info to mount samba share (drivercache)
mountpoint='/mnt/samba'
downloadscript="./mscatalog_tux.bash"
download_basefolder='/tmp'
download_basefolder='/mnt/p3/mscatalog_tux'
if [ ! -d "${download_basefolder}" ]; then mkdir -p "${download_basefolder}"; fi
remotefolder_prefix="MINIMUM_DRIVERS"
# Timezone used for time display
export TZ=Europe/Berlin

# cleanup function
cleanup() {
  echo "Cleaning up…"
  # sync file system operations
  sync
  # e.g., remove temp files, release locks
  umount -f "${mountpoint}" 2>/dev/null
  umount -f "/mnt/p3" 2>/dev/null
}
trap cleanup EXIT       # always run cleanup function at script end
trap cleanup INT INT    # Ctrl-C
trap cleanup TERM       # kill
trap cleanup HUP        # terminal closed

##################################################################################################
# systeminfo
##################################################################################################
# pkid (windows product key)
pkid=$(sudo grep -a -o '[[:print:]]\+' /sys/firmware/acpi/tables/MSDM | tail -n 1)
# system_lan_mac
# check IP starts with '192.168.124' and that businfo does not start with usb
# this will detect the port we are currently connected to the PXE server
# if it is not a usb card
system_lan_mac=$(lshw -json -class network -quiet 2>/dev/null | jq -r '.[] | select((.configuration.ip? // "" | tostring | startswith("192.168.124")) and (.businfo? // "" | tostring | startswith("usb") | not)) | .serial' | tr '[:lower:]' '[:upper:]' | sed 's@:@-@g'|| echo "")

# wifimac
# all network devices where
# - no configuration.port value is present
# - configuration.port is present but empty
# then we can assume this is the wireless card since
# a LAN card would have port="twisted pair"
wifi_mac=$(lshw -json -class network 2>/dev/null | jq -r '.[] | select((.configuration.port? // "") == "") | select(.businfo? // "" | tostring | startswith("usb") | not) | .serial' | tr '[:lower:]' '[:upper:]' | sed 's@:@-@g' || echo "")

# Use the dmidecode command to get detailled
# information about our hardware from BIOS
# next lines requires sudo or root privileges
bios_vendor=$(sudo dmidecode -s bios-vendor)
bios_version=$(sudo dmidecode -s bios-version)
bios_release_date=$(sudo dmidecode -s bios-release-date)
bios_revision=$(sudo dmidecode -s bios-revision)
firmware_revision=$(sudo dmidecode -s firmware-revision)
system_manufacturer=$(sudo dmidecode -s system-manufacturer)
system_product_name=$(sudo dmidecode -s system-product-name)
system_version=$(sudo dmidecode -s system-version)
system_serial_number=$(sudo dmidecode -s system-serial-number)
system_uuid=$(sudo dmidecode -s system-uuid)
system_sku_number=$(sudo dmidecode -s system-sku-number)
system_family=$(sudo dmidecode -s system-family)
baseboard_manufacturer=$(sudo dmidecode -s baseboard-manufacturer)
baseboard_product_name=$(sudo dmidecode -s baseboard-product-name)
baseboard_version=$(sudo dmidecode -s baseboard-version)
baseboard_serial_number=$(sudo dmidecode -s baseboard-serial-number)
baseboard_asset_tag=$(sudo dmidecode -s baseboard-asset-tag)
chassis_manufacturer=$(sudo dmidecode -s chassis-manufacturer)
chassis_type=$(sudo dmidecode -s chassis-type)
chassis_version=$(sudo dmidecode -s chassis-version)
chassis_serial_number=$(sudo dmidecode -s chassis-serial-number)
chassis_asset_tag=$(sudo dmidecode -s chassis-asset-tag)
processor_family=$(sudo dmidecode -s processor-family)
processor_manufacturer=$(sudo dmidecode -s processor-manufacturer)
processor_version=$(sudo dmidecode -s processor-version)
processor_frequency=$(sudo dmidecode -s processor-frequency)
##################################################################################################

# defining a subfolder based on hardware details
# e.g. for an HP ProBook 650 G5 this will result in
# '856E-HP_ProBook_650_G5'
devicefoldername=$(echo "$baseboard_product_name-$system_product_name"| sed 's@\s@_@g')
download_dir=$(echo "${download_basefolder}/$devicefoldername"| sed 's@\s@_@g')
echo "download_dir: $download_dir"

# create mountpoint directory if not exists
if [ ! -d "${mountpoint}" ]; then mkdir -p "${mountpoint}"; fi

# mount share
mount -t cifs "//${SMBSERVER}/${SMBSHARE}" -o "username=${SMBUSERNAME},password=${SMBPASSWORD},domain=${SMBDOMAIN}" "${mountpoint}"

if [ ! -d "${mountpoint}/${remotefolder_prefix}/${devicefoldername}" ]; then # if no folder for device exists on share, yet
 # create remote download_dir
 mkdir -p "${mountpoint}/${remotefolder_prefix}/${devicefoldername}" 2>/dev/null
 # create local download_dir
 if [ ! -d "${download_dir}" ]; then mkdir -p "${download_dir}"; fi
 # download drivers to local download dir
 "${downloadscript}" "${download_dir}"
 # add a textfile with information about the system that downloaded the drivers
 # and the date/time to the local download dir
 mynow=$(date "+%Y-%M-%d %H:%M:%S $TZ")
cat << EOF > "${download_dir}/ZZZ_DRIVERINFORMATION.TXT"
  -------------------------------------------------------------------------------------------------------------
  FOLDER                : $devicefoldername
  CREATION DATE         : $mynow
  -------------------------------------------------------------------------------------------------------------
  THIS DRIVERCACHE FOLDER HAS BEEN CREATED ON THE FOLLOWING SYSTEM
  -------------------------------------------------------------------------------------------------------------
  SYSTEM MANUFACTURER    : $system_manufacturer
  SYSTEM                 : $system_product_name $system_version $system_sku_number
  SYSTEM FAMILY          : $system_family
  BASEBOARD PRODUCT NAME : $baseboard_product_name
  BASEBOARD MANUFACTURER : $baseboard_manufacturer
  SYSTEM SERIAL          : $system_serial_number
  SYSTEM UUID            : $system_uuid
  BIOS                   : $bios_vendor $bios_version REVISION: $bios_revision DATE: $bios_release_date
  FIRMWARE               : $firmware_revision
  PKID (from BIOS)       : $pkid
  BASEBOARD              : $baseboard_version $baseboard_serial_number $baseboard_asset_tag
  CHASSIS                : $chassis_manufacturer $chassis_type $chassis_version $chassis_serial_number $chassis_asset_tag
  PROCESSOR              : $processor_family $processor_manufacturer $processor_version $processor_frequency
  -------------------------------------------------------------------------------------------------------------
  MAC ADDR WIRED         : $system_lan_mac
  MAC ADDR WIRELESS      : $wifi_mac
  -------------------------------------------------------------------------------------------------------------
  To install in Windows  : PNPUTIL /add-driver ${remotefolder_prefix}\\${devicefoldername}\*.inf /subdirs /install
  -------------------------------------------------------------------------------------------------------------
EOF
 # create remote directory on share
 mkdir -p "${mountpoint}/${remotefolder_prefix}"
 # copy drivers to share
 cp -R "${download_dir}/" "${mountpoint}/${remotefolder_prefix}"
 # add DRIVERINFORMATION.TXT
 find "${mountpoint}/${remotefolder_prefix}/${devicefoldername}" \
  -type f \
  -printf "  ${remotefolder_prefix}/${devicefoldername}/%P\n" >> "${mountpoint}/${remotefolder_prefix}/${devicefoldername}/ZZZ_DRIVERINFORMATION.TXT"
  # remove lockfile
  if [ ! -f "${lockfile}" ]; then rm -f "${lockfile}"; fi
else
 # copy drivers from drivercache share to "${download_basefolder}"
 cp -R "${mountpoint}/${remotefolder_prefix}/${devicefoldername}/" "${download_basefolder}"
fi
