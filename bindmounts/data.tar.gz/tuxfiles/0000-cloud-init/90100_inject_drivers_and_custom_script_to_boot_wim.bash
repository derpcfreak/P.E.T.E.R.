#!/bin/bash
###################################################################################
# inject_drivers_and_custom_script_to_boot_wim.bash
###################################################################################
# Injects custom drivers and automated setup script into Windows PE boot.wim
# (index 2). Configures WinPE to automatically load drivers and launch Windows
# setup without user intervention.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Identifies target disk using helper script with safety checks
#   4. Determines partition naming convention (p1-p4 vs 1-4)
#   5. Creates mount directories: /mnt/p1, /mnt/p3, /mnt/p4, /mnt/wim
#   6. Mounts partitions:
#      - p3: Data partition (used as staging directory for WIM operations)
#      - p4: Recovery partition (contains boot.wim to be modified)
#   7. Mounts boot.wim index 2 (Setup WinPE) read-write to /mnt/wim
#   8. Copies driver package from /mnt/p3/mscatalog_tux/ to /mnt/wim/mscatalog_tux/
#   9. Creates /mnt/wim/peter.cmd script that:
#      - Pre-loads drivers using drvload.exe (avoids conflicts with inbox drivers)
#      - Installs drivers to driverstore using pnputil.exe /add-driver /install
#      - Launches X:\setup.exe if it exists
#   10. Creates winpeshl.ini in System32 directory to:
#       - Execute peter.cmd automatically when WinPE boots
#       - Provide fallback command shell if peter.cmd doesn't exist
#   11. Commits changes to boot.wim and unmounts WIM image
#   12. Unmounts partitions and syncs filesystem
#
# Driver Loading Strategy:
# Two-stage loading prevents conflicts - drvload first establishes driver presence,
# then pnputil adds them to driverstore for Windows installation without conflicting
# with inbox drivers that would cause setup failures.
#
# Result: Modified boot.wim will automatically load custom drivers and launch
# Windows setup when booted, enabling unattended installation on hardware requiring
# additional drivers not included in the Windows ISO.
#
# Exit strategy: Enters infinite sleep if target disk cannot be identified.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash
me=$(basename "$0")

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi
# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

### NOW IT BEGINS

# create mount directories if not already exist
mkdir /mnt/p1 2>/dev/null
mkdir /mnt/p3 2>/dev/null
mkdir /mnt/p4 2>/dev/null
mkdir /mnt/wim 2>/dev/null

# mount p3 to /mnt/p3
mount "${diskdev}${prefix}3" /mnt/p3
# mount p4 to /mnt/p4
mount "${diskdev}${prefix}4" /mnt/p4
# mount p3 to /mnt/p3

# mount index 1 (setup-winpe) rw to /mnt/wim and use
# /mnt/p3 as staging dir
wimmountrw /mnt/p4/sources/boot.wim 2 /mnt/wim/ --staging-dir=/mnt/p3

#####################################################################################
#  work with index 1
#####################################################################################
# copy /mnt/p3/mscatalog_tux to /mnt/wim
# so it will become X:\mscatalog_tux when booted to setup-winpe
#####################################################################################
cp -Rv /mnt/p3/mscatalog_tux/ '/mnt/wim/'

#####################################################################################
# create peter.cmd as /mnt/wim/peter.cmd
# so it will become X:\peter.cmd when bootet to setup-winpe
#####################################################################################
cat << EOF > '/mnt/wim/peter.cmd'
REM ###############################################################
REM X:\peter.cmd
REM ###############################################################
echo Try to load drivers from from X:\mscatalog_tux using drvload.
echo This is a trick to bring drivers into the system without creating
echo driver conflicts with already loaded drivers.
if exist X:\mscatalog_tux\. (
 for /R X:\mscatalog_tux\ %%D in (*.inf) do drvload.exe "%%D"
)

echo Try to load drivers from X:\mscatalog_tux using pnputil.
echo Because we previously loaded the same drivers using drvload
echo pnputil /install will now add them to the driverstore and make
echo them available for the "future" windows.
echo If you only use pnputil without previous drvload, then pnputil
echo will create possible conflicts with already built-in/delivered
echo drivers from the original installation media and setup will
echo fail with error!
if exist X:\mscatalog_tux\. (
 pnputil.exe /add-driver X:\mscatalog_tux\*.inf /subdirs /install
)

echo Starting X:\setup.exe if exists
if exist X:\setup.exe (
 echo setup.exe
)
EOF

# create a winpeshl.ini to make sure 'x:\peter.cmd' gets executed
# if it exists
# change from /c to /k if final
winsystem32=$(find /mnt/wim/ -type d -iname "system32" | head -n 1)

cat << EOF > "$winsystem32/winpeshl.ini"
[Comments a non official section but ignored]
comment100="      __________ ___________________________________________                                 "
comment101="      \______   \\_   _____/\__    ___/\_   _____/\______   \                                "
comment102="       |     ___/ |    __)_   |    |    |    __)_  |       _/                                "
comment103="       |    |     |        \  |    |    |        \ |    |   \                                "
comment104="       |____|    /_______  /  |____|   /_______  / |____|_  /                                "
comment105="                         \/                    \/         \/                                 "
comment106="    ------------------------------------------------------------                             "
comment107="    Professional Environment for Technically Efficient Reimaging                             "
comment108="    ------------------------------------------------------------                             "
comment109="    This winpeshlp.ini has been injected into \Sources\boot.wim by the P.E.T.E.R. system.    "
comment110="    It makes sure that the first instance of peter.cmd found on any drive is executed        "
comment111="                                                                                             "
comment112="    Info: [LaunchApps] can contain multiple CommandLine entries                              "
comment113="    e.g.  %systemroot%\system32\cmd.exe, /k echo You are now in WinPE                        "
comment114="    !!!   max length of command = 250 characters !!!                                         "
comment115="    !!!   There MUST be a ',' after the command before the paramters !!!                     "
comment116="    Info  [LaunchApp]  can only contain one AppPath and CommandLine entry                    "
comment117="    e.g.  AppPath=%systemroot%\system32\cmd.exe                                              "
comment118="    !!!   You can’t specifiy any command-line options with LaunchApp !!!                     "

[LaunchApps]
%SYSTEMROOT%\System32\cmd.exe, /c if exist "X:\peter.cmd" ( echo REM it works >> "X:\peter.cmd" ) else ( echo REM failed >> "X:\peter.cmd" )
%SYSTEMROOT%\System32\cmd.exe, /k if exist "X:\peter.cmd" "X:\peter.cmd"
EOF
wimunmount --commit /mnt/wim/ # commit the writes
#####################################################################################

# create new startnet.cmd
#  find startnet.cmd full path and store into variable startnet
#startnet1=$(find /mnt/wim -iname "startnet.cmd" 2>/dev/null | head -n 1)
#echo "wpeinit" > "$startnet1"
#echo "cmd.exe /c for %%a in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do if exist %%a:\mscatalog_tux\. pnputil /add-driver %%a:\mscatalog_tux\*.inf /subdirs /install" >> "$startnet1"
#echo "wpeutil InitializeNetwork" >> "$startnet1"
# unmount the wimfile and commit changes
#wimunmount --commit /mnt/wim/ # commit the writes
#####################################################################################

# unmount /mnt/p3
unmount /mnt/p3 2>/dev/null
# unmount /mnt/p4
unmount /mnt/p4 2>/dev/null

# sync file system operations
sync
