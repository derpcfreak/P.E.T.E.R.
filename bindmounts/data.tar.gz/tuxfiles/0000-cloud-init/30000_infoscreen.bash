#!/bin/bash
###################################################################################
# 3000_infoscreen.bash
###################################################################################
# Collects and displays detailed hardware information from system firmware and 
# hardware components. Useful for diagnostics, inventory, and pre-installation
# verification.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Queries DMI/BIOS information using dmidecode:
#      - BIOS vendor, version, revision, and release date
#      - System manufacturer, product name, version, serial, UUID, SKU, family
#      - Baseboard manufacturer, product, version, serial, asset tag
#      - Chassis manufacturer, type, version, serial, asset tag
#      - Processor family, manufacturer, version, frequency
#   3. Extracts embedded Windows Product Key (PKID) from ACPI MSDM table
#   4. Collects MAC addresses from all network interfaces (excluding loopback)
#   5. Gathers storage controller information using lshw (JSON parsing):
#      - Controller ID, vendor, product name, logical device name
#   6. Outputs formatted hardware inventory report to console
#
# Use case: Pre-installation hardware verification for Windows deployment,
# capturing system information for documentation or troubleshooting purposes.
#
# Dependencies: dmidecode, lshw, jq, access to /sys/firmware/acpi/tables/
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config

# Use the dmidecode command to get detailled
# information about our hardware from BIOS
bios_vendor=$(dmidecode -s bios-vendor) 
bios_version=$(dmidecode -s bios-version) 
bios_release_date=$(dmidecode -s bios-release-date) 
bios_revision=$(dmidecode -s bios-revision) 
firmware_revision=$(dmidecode -s firmware-revision) 
system_manufacturer=$(dmidecode -s system-manufacturer) 
system_product_name=$(dmidecode -s system-product-name) 
system_version=$(dmidecode -s system-version) 
system_serial_number=$(dmidecode -s system-serial-number) 
system_uuid=$(dmidecode -s system-uuid) 
system_sku_number=$(dmidecode -s system-sku-number) 
system_family=$(dmidecode -s system-family) 
baseboard_manufacturer=$(dmidecode -s baseboard-manufacturer) 
baseboard_product_name=$(dmidecode -s baseboard-product-name) 
baseboard_version=$(dmidecode -s baseboard-version) 
baseboard_serial_number=$(dmidecode -s baseboard-serial-number) 
baseboard_asset_tag=$(dmidecode -s baseboard-asset-tag) 
chassis_manufacturer=$(dmidecode -s chassis-manufacturer) 
chassis_type=$(dmidecode -s chassis-type) 
chassis_version=$(dmidecode -s chassis-version) 
chassis_serial_number=$(dmidecode -s chassis-serial-number) 
chassis_asset_tag=$(dmidecode -s chassis-asset-tag) 
processor_family=$(dmidecode -s processor-family) 
processor_manufacturer=$(dmidecode -s processor-manufacturer) 
processor_version=$(dmidecode -s processor-version) 
processor_frequency=$(dmidecode -s processor-frequency) 

# Windows Product Key from BIOS using commands we have available.
pkid=$(grep -a -o '[[:print:]]\+' /sys/firmware/acpi/tables/MSDM | tail -n 1)

# mac addresses
mac_addresses=$(for card in $(find /sys/class/net/ -mindepth 1 -print | grep -v 'lo'); do tr '\n' ',' < "${card}/address" |sed 's@,$@@g';done)

# storage device info
jresult=$(lshw -json -class storage 2>/dev/null)
count=$(echo "$jresult" | jq 'length')
if [[ "$count" -le 0 ]]; then count=0;fi # make sure to check if jresult has no array at all
for (( a=0; a<count; a++ ))
do
        s_id=$(echo "${jresult}" | jq -r ".[$a].id")
        s_vendor=$(echo "${jresult}" | jq -r ".[$a].vendor")
        s_product=$(echo "${jresult}" | jq -r ".[$a].product")
        s_logicalname=$(echo "${jresult}" | jq -r ".[$a].logicalname")
        storage="${s_id}  ${s_vendor}  ${s_product} ${s_logicalname}"
        storage_info+="${storage},"
done


# Output to screen
echo "-------------------------------------------------------------------------------------------------------------"
echo "SYSTEM MANUFACTURER   : $system_manufacturer"
echo "SYSTEM                : $system_product_name $system_version $system_sku_number"
echo "SYSTEM SERIAL         : $system_serial_number"
echo "SYSTEM UUID           : $system_uuid"
echo "SYSTEM FAMILY         : $system_family"
echo "BASEBOARD MANUFACTURER: $baseboard_manufacturer"
echo "BASEBOARD PRODUCT NAME: $baseboard_product_name"
echo "BIOS                  : $bios_vendor $bios_version REVISION: $bios_revision DATE: $bios_release_date"
echo "FIRMWARE              : $firmware_revision"
echo "PKID (from BIOS)      : $pkid"
echo "BASEBOARD             : $baseboard_version $baseboard_serial_number $baseboard_asset_tag"
echo "CHASSIS               : $chassis_manufacturer $chassis_type $chassis_version $chassis_serial_number $chassis_asset_tag"
echo "PROCESSOR             : $processor_family $processor_manufacturer $processor_version $processor_frequency"
echo "MAC ADDRESS(ES)       : $mac_addresses"
echo "STORAGE               : $storage_info" | sed 's@,$@@g'
echo "-------------------------------------------------------------------------------------------------------------"

