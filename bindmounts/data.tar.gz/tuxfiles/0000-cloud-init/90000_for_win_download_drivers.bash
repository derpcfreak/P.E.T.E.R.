#!/bin/bash

# cd into subfolder driver (/dev/shm/driver)
# and execute drivercache.bash
# to download boot-critical drivers from mscatalog
# for the current hardware
#
# This should be able to get network networking in WinPE
# and make the disk accessible for Windows setup
#
# Drivers will be stored in /mnt/p3/mscatalog_tux
cd ./driver
exec ./drivercache.bash
cd ..
exit
