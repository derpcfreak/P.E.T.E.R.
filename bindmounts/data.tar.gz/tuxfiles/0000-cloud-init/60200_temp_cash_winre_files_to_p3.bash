#!/bin/bash
###################################################################################
# temp_cash_winre_on_p3.bash
###################################################################################
# This script will mount /mnt/p4/sources/install.wim or install.esd and
# then copy the WindowsRE files out of it and stores them in /mnt/p3/recovery.tmp
# to be used by peter.cmd after Windows setup.exe is completed
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash

# unmount all possibly mounted wim files (to ensure this script can also be executed manually)
mount | grep 'type fuse.wimfs' | awk '{print $3}' | while read -r mountpoint; do
    echo "Unmounting: $mountpoint"
    wimunmount "$mountpoint" 2>/dev/null
done

# unmount all possible mountpoints (to ensure this script can also be executed manually)
mount | grep ' /mnt/' | awk '{print $3}' | sort -r | while read -r mountpoint; do
    echo "Unmounting: $mountpoint"
    umount -f -l "$mountpoint"
done

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi
# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

### NOW IT BEGINS

# create mount directories
mkdir /mnt/isomount 2>/dev/null
mkdir /mnt/p1 2>/dev/null
mkdir /mnt/p3 2>/dev/null
mkdir /mnt/p4 2>/dev/null
mkdir /mnt/wim 2>/dev/null

# mount p3 to /mnt/p3
mount "${diskdev}${prefix}3" /mnt/p3

# mount p4 to /mnt/p4
mount "${diskdev}${prefix}4" /mnt/p4

# find the full path to install.wim on p4
installwim=$(find /mnt/p4/ -regextype posix-extended -regex '.*/install\.(wim|esd)' | head -n1)
# mount index 1 of /mnt/p4/sources/install.wim to /mnt/wim
# any index in install.wim should contain winre
wimmount "${installwim}" 1 /mnt/wim

# find path to winre.wim. This is needed since paths could
# be case sensitive inside install.wim from linux side of view
winrepath=$(find /mnt/wim/ -iname winre.wim | head -n1 | awk -F '/' 'BEGIN{OFS=FS} {$NF=""; print}')

# copy WinRE files to /mnt/p3/recovery.tmp
rsync -av "${winrepath}/" /mnt/p3/recovery.tmp/

# sync file system operations
sync

# unmount /mnt/wim
wimunmount /mnt/wim

# sync file system operations
sync

# unmount /mnt/p3
umount /mnt/p3
sleep 1
# unmount /mnt/p4
umount /mnt/p4
sleep 1

# sync file system operations
sync
