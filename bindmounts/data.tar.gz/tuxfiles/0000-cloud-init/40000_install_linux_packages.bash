#!/bin/bash
###################################################################################
# install_linux_packages.bash
###################################################################################
# Downloads and installs additional Linux packages into the live system from an
# http server. Provides tools required for Windows deployment operations that are
# not included in the base Ubuntu Live ISO.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Downloads .deb packages from HTTP server (http://pxeserver/amd64-web/tuxfiles/packages)
#   4. Installs packages with dependencies in correct order using dpkg --force-all
#   5. Cleans up downloaded files from /dev/shm after installation
#
# Packages installed:
#   - unzip: Archive extraction utility
#   - wimtools + dependencies: WIM image manipulation (libntfs, libfuse3, libwim15)
#   - clevis + jose + dependencies: Disk encryption and LUKS management
#   - figlet: ASCII art text generation for console output
#   - cabextract: Microsoft Cabinet file extraction
#   - efitools + sbsigntool: UEFI secure boot and signature tools
#   - luksmeta + libluksmeta: LUKS metadata management
#
# Notes:
#   - Package versions are hardcoded and must match Ubuntu Live ISO version
#   - All packages downloaded to /dev/shm (RAM) to avoid disk writes
#   - Uses custom install_packages() function for batch download and installation
#
# WARNING: If Ubuntu Live ISO is updated, package versions may need adjustment
# This script might need some rewriting but works for now.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config

# show an image on screen
/dev/shm/Z0_show_image_per_script.bash

# base URL for packages
baseurl="http://pxeserver/amd64-web/tuxfiles/packages"

echo "Installing additional Linux packages into the live system"

# function to download and install one or more .deb packages at once
# this function will be called multiple times from the rest of the script
install_packages() {
    local files=("$@")
    local targets=()

    # Download all files first
    for file in "${files[@]}"; do
        echo -n " $file..."
        local target="/dev/shm/$file"
        wget -nv "$baseurl/$file" -O "$target" > /dev/null 2>&1
        targets+=("$target")
    done

    # Install all downloaded packages in one dpkg command
    dpkg --force-all -i "${targets[@]}"

    # Cleanup
    for target in "${targets[@]}"; do
        rm "$target"
    done
    echo "done."
}

# ---------------------------
# Install packages in order
# ---------------------------

# unzip
install_packages "unzip_6.0-28ubuntu4_amd64.deb"

# wimtools and dependencies
install_packages "libntfs-3g89t64_2022.10.3-1.2ubuntu3_amd64.deb" \
                 "libfuse3-3_3.14.0-5build1_amd64.deb" \
                 "libwim15t64_1.14.4-1.1build2_amd64.deb" \
                 "wimtools_1.14.4-1.1build2_amd64.deb"

# clevis and jose with dependencies
install_packages "wamerican_2020.12.07-2_all.deb"
install_packages "cracklib-runtime_2.9.6-5.1build2_amd64.deb" \
                 "libcrack2_2.9.6-5.1build2_amd64.deb"
install_packages "libpwquality-common_1.4.5-3build1_all.deb"
install_packages "libpwquality1_1.4.5-3build1_amd64.deb"
install_packages "libpwquality-tools_1.4.5-3build1_amd64.deb"
install_packages "libjose0_13-1_amd64.deb"
install_packages "jose_13-1_amd64.deb"
install_packages "clevis_20-1_amd64.deb"

# figlet
install_packages "figlet_2.2.5-3_amd64.deb"

# cabextract
install_packages "cabextract_1.11-2_amd64.deb"

# efitools and related packages
install_packages "sbsigntool_0.9.4-3.1ubuntu3_amd64.deb"
install_packages "efitools_1.9.2-1ubuntu3_amd64.deb"
install_packages "luksmeta_9-4_amd64.deb"
install_packages "libluksmeta0_9-4_amd64.deb"

