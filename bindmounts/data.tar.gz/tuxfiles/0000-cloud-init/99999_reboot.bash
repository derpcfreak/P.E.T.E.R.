#!/bin/bash
###################################################################################
# reboot.bash
###################################################################################
# Completes the automated Windows installation preparation process by either
# rebooting to launch Windows Setup or entering troubleshooting mode for
# manual debugging via SSH.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Retrieves current system IP address using hostname -I
#   4. Checks TROUBLESHOOTING variable value:
#
#      (normal mode):
#        - Changes to /dev/shm directory
#        - Unmounts all partitions (p1-p4) to ensure clean reboot
#        - Displays 10-second countdown message
#        - Initiates system reboot
#        - Result: System boots into Windows Setup using UEFI entry created earlier
#
#      If TROUBLESHOOTING=1 (debug mode) additionally:
#        - Displays "Troubleshooting Mode - Automatic Reboot disabled"
#        - Shows system IP address for SSH access
#        - Indicates SSH credentials from variables.config (SSHUSER, SSHPASS)
#        - Suggests checking /var/log/cloud-init-output.log for debugging
#        - System remains running in Ubuntu Live environment
#
# Use cases:
#   - Normal operation: Automatically reboot to complete Windows installation
#   - Troubleshooting: Keep system accessible for manual intervention and log review
#
# Note: SSH credentials must match encrypted values in cloud-init.yaml for
# authentication to work in troubleshooting mode.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash
me=$(basename "$0")
#echo -e "${LIGHTBLUE}running ${me}${NC}" | tee "${TTY}"

# get current IP address
myip=$(hostname -I) # shows IP address only

# honor TROUBLESHOOTING variable - reboot or not?
if [ "$TROUBLESHOOTING" == "0" ]
then
 cd /dev/shm
 umount /mnt/p1 2>/dev/null
 umount /mnt/p2 2>/dev/null
 umount /mnt/p3 2>/dev/null
 umount /mnt/p4 2>/dev/null
 echo -e -n "rebooting in 10 seconds....."
 sleep 10
 reboot # REBOOT
else
# echo "Troubleshooting Mode - Automatic Reboot disabled." | tee "${TTY}"
# myip=$(hostname -I) # shows IP address only
# echo "You can use SSH to connect using" | tee "${TTY}"
# echo -e "\n" | tee "${TTY}"
# echo "            IP      : ${myip}" | tee "${TTY}"
# echo "            USERNAME: ${SSHUSER}" | tee "${TTY}"
# echo "            PASSWORD: ${SSHPASS}" | tee "${TTY}"
# echo -e "\n" | tee "${TTY}"
# echo "looking at '/var/log/cloud-init-output.log' should also help you." | tee "${TTY}"
echo "Troubleshooting Mode - Automatic Reboot disabled."
myip=$(hostname -I) # shows IP address only
echo "You can use SSH to connect using"
echo -e "\n"
echo "            IP      : ${myip}"
echo -e "\n"
echo "looking at '/var/log/cloud-init-output.log' should also help you."
fi
