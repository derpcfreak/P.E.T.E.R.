#!/bin/bash
###################################################################################
# for_win_prepare_files_on_disk.bash
###################################################################################
# Prepares the EFI System Partition (p1) with minimal Windows boot files to
# launch Windows Setup. Creates a split-source installation where boot files
# reside on p1 and installation files remain on p4.
#
# Operations performed:
#   1. Sources configuration variables from ./variables.config
#   2. Displays progress image on screen
#   3. Identifies target disk using helper script with safety checks
#   4. Determines partition naming convention (p1-p4 vs 1-4)
#   5. Creates mount directories: /mnt/p1, /mnt/p4, /mnt/wim
#   6. Mounts partitions:
#      - p1: EFI System Partition (FAT32, destination for boot files)
#      - p4: Recovery partition (NTFS, source containing full Windows ISO)
#   7. Copies Windows boot infrastructure from p4 to p1:
#      - Uses rsync with --exclude 'sources' to copy all files except sources directory
#      - This includes bootmgr.efi, BCD, and EFI boot files
#   8. Creates /mnt/p1/sources directory
#   9. Copies only boot.wim from /mnt/p4/sources/ to /mnt/p1/sources/
#      - boot.wim contains Windows PE for setup
#      - install.wim remains on p4 (accessed during installation)
#   10. Unmounts both partitions
#
# Rationale:
# EFI System Partition (p1) is typically FAT32 with size limitations. This
# script copies only essential boot files to p1, while the large install.wim
# and other installation files remain on p4 (NTFS) where Windows Setup can
# access them during installation.
#
# Reference: https://blog.emacsos.com/install-win10-from-hard-drive.html
#
# Exit strategy: Enters infinite sleep if target disk cannot be identified.
###################################################################################
# variables in CAPITALS are sourced from ./variables.config

# source variables from variables.config
source ./variables.config
/dev/shm/Z0_show_image_per_script.bash
me=$(basename "$0")

# Identify disk using helperscript
diskdev="$(/dev/shm/Z0_identify_target_block_device.bash)" # this script also has it's own checks
if [ -z "${diskdev+x}" ] # if length of diskdev is zero (undefined)
then
 #echo "Variable diskdev not set, will stop here." | tee "${TTY}"
 echo "Variable diskdev not set, will stop here."
 # infinite sleep
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 while :; do sleep 2073600; done
 exit 1
fi
# if $diskdev ends with a number partitions must be prefixed with 'p'
if [[ "$diskdev" =~ [0-9]$ ]]; then
    prefix='p'
else
    prefix=''
fi
echo "partition prefix is: ${prefix}"

### NOW IT BEGINS

# create mount directories
echo -e -n "preparing a partition to hold Windows installation files..."

mkdir /mnt/p1 2>/dev/null
mkdir /mnt/p4 2>/dev/null
mkdir /mnt/wim 2>/dev/null

# mount p1 to /mnt/p1
mount "${diskdev}${prefix}1" /mnt/p1

# mount p4 to /mnt/p4
mount "${diskdev}${prefix}4" /mnt/p4

# Copy all files except /sources dir from /mnt/p4 to /mnt/p1,
# then create empty dir /mnt/p1/sources and copy /mnt/p4/sources/boot.wim /mnt/p1/sources
rsync -av --exclude 'sources' /mnt/p4/ /mnt/p1/
mkdir /mnt/p1/sources 2>/dev/null
cp -f /mnt/p4/sources/boot.wim /mnt/p1/sources

# unmount /mnt/p1
umount /mnt/p1
# unmount /mnt/p4
umount /mnt/p4
