#!/usr/bin/env bash
# List all physical wired NICs (exclude wireless and virtual), show vendor/device IDs & driver,
# and finally print UNIQUE VendorID:DeviceID combinations seen.
#
# Debug control:
#   debug=1  -> verbose per-NIC details + final summary (default)
#   debug=0  -> ONLY final unique summary
#
# Works without root. Optional tools used: lspci, lsusb, ethtool.

set -euo pipefail

# ---------------- Configuration ----------------
debug="${debug:-0}"   # Set to 0 for only the final summary

# ---------------- Utilities ----------------
have() { command -v "$1" >/dev/null 2>&1; }
log()  { [[ "$debug" -eq 1 ]] && echo -e "$*"; }

is_wireless() {
  local if="$1"
  # Wireless interfaces usually have /sys/class/net/<if>/wireless or phy80211
  [[ -d "/sys/class/net/$if/wireless" || -L "/sys/class/net/$if/phy80211" ]]
}

is_virtual_iface() {
  local if="$1"
  # If the /sys path points under /devices/virtual/net, it's not backed by physical hardware
  local link
  link="$(readlink -f "/sys/class/net/$if")"
  [[ "$link" == *"/devices/virtual/"* ]]
}

get_mac() {
  local if="$1"
  [[ -r "/sys/class/net/$if/address" ]] && cat "/sys/class/net/$if/address" || echo "unknown"
}

# A small in-script set implementation for uniqueness of VID:DID
declare -A uniq_vid_did

add_vid_did() {
  local vid="$1" did="$2"
  [[ -z "$vid" || -z "$did" ]] && return 0
  uniq_vid_did["$vid:$did"]=1
}

print_pci_info() {
  local if="$1" devpath="$2"
  # Walk up to find a PCI function directory 0000:BB:DD.F
  local cur="$devpath" base pci_addr=""
  for _ in {1..12}; do
    base="$(basename "$cur")"
    if [[ "$base" =~ ^0000:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]]; then
      pci_addr="$base"; break
    fi
    local parent
    parent="$(readlink -f "$cur/..")"
    [[ "$parent" == "$cur" || "$parent" == "/" ]] && break
    cur="$parent"
  done

  if [[ -n "$pci_addr" ]]; then
    local vendor_id device_id driver human drv_line
    vendor_id="$(sed 's/^0x//' "/sys/bus/pci/devices/$pci_addr/vendor" 2>/dev/null || true)"
    device_id="$(sed 's/^0x//' "/sys/bus/pci/devices/$pci_addr/device" 2>/dev/null || true)"
    driver=""
    [[ -L "/sys/bus/pci/devices/$pci_addr/driver" ]] && driver="$(basename "$(readlink -f "/sys/bus/pci/devices/$pci_addr/driver")")"

    human=""
    if have lspci; then
      human="$(lspci -s "$pci_addr" -nn 2>/dev/null || true)"
      drv_line="$(lspci -s "$pci_addr" -k 2>/dev/null | sed -n 's/^\s*Kernel driver in use:\s*//p' | head -n1)"
      [[ -n "$drv_line" && -z "$driver" ]] && driver="$drv_line"
    fi

    if [[ "$debug" -eq 1 ]]; then
      log "Bus              : PCI"
      log "Controller (PCI) : $pci_addr"
      [[ -n "$human"     ]] && log "Controller info  : $human"
      [[ -n "$vendor_id" ]] && log "Vendor ID        : $vendor_id"
      [[ -n "$device_id" ]] && log "Device ID        : $device_id"
      if have ethtool; then
        ethtool -i "$if" 2>/dev/null | sed -n 's/^driver:\s*/Kernel driver    : /p' | while IFS= read -r L; do log "$L"; done
      else
        [[ -n "$driver" ]] && log "Kernel driver    : $driver"
      fi
    fi

    # Add to unique set
    add_vid_did "$vendor_id" "$device_id"
    return 0
  fi
  return 1
}

print_usb_info() {
  local if="$1" devpath="$2"
  # USB NICs expose idVendor/idProduct under the device node
  local vendor_id device_id driver human
  if [[ -r "$devpath/idVendor" && -r "$devpath/idProduct" ]]; then
    vendor_id="$(cat "$devpath/idVendor" 2>/dev/null || true)"
    device_id="$(cat "$devpath/idProduct" 2>/dev/null || true)"
    driver=""
    if have ethtool; then
      driver="$(ethtool -i "$if" 2>/dev/null | sed -n 's/^driver:\s*//p' | head -n1)"
    fi
    [[ -z "$driver" && -L "$devpath/driver" ]] && driver="$(basename "$(readlink -f "$devpath/driver")")"

    human=""
    if have lsusb; then
      # Try to find a matching line by VID:PID (case-insensitive)
      human="$(lsusb | grep -i -E "${vendor_id}:${device_id}" || true)"
    fi

    if [[ "$debug" -eq 1 ]]; then
      log "Bus              : USB"
      [[ -n "$human"     ]] && log "Adapter info     : $human"
      [[ -n "$vendor_id" ]] && log "Vendor ID        : $vendor_id"
      [[ -n "$device_id" ]] && log "Device ID        : $device_id"
      [[ -n "$driver"    ]] && log "Kernel driver    : $driver"
    fi

    # Add to unique set
    add_vid_did "$vendor_id" "$device_id"
    return 0
  fi
  return 1
}

# ---------------- Enumerate all candidate NICs ----------------
for link in /sys/class/net/*; do
  ifname="$(basename "$link")"
  # Skip loopback and common virtual prefixes quickly
  [[ "$ifname" == "lo" ]] && continue
  [[ "$ifname" =~ ^(br|bond|vlan|vnet|veth|tap|tun|docker|virbr|wg|zt|vmnet) ]] && continue

  # Must not be virtual
  if is_virtual_iface "$ifname"; then
    continue
  fi

  # Must not be wireless
  if is_wireless "$ifname"; then
    continue
  fi

  # Must have a /device entry (physical backing)
  if [[ ! -e "/sys/class/net/$ifname/device" ]]; then
    continue
  fi

  if [[ "$debug" -eq 1 ]]; then
    mac="$(get_mac "$ifname")"
    log "Interface        : $ifname"
    log "MAC              : $mac"
  fi

  devpath="$(readlink -f "/sys/class/net/$ifname/device")"
  bus="unknown"
  [[ -d "$devpath/subsystem" ]] && bus="$(basename "$(readlink -f "$devpath/subsystem")")"

  # Prefer PCI; if not PCI, try USB; else emit minimal only in debug
  if ! print_pci_info "$ifname" "$devpath"; then
    if ! print_usb_info "$ifname" "$devpath"; then
      if [[ "$debug" -eq 1 ]]; then
        log "Bus              : $bus"
        if have ethtool; then
          ethtool -i "$ifname" 2>/dev/null | sed -n 's/^driver:\s*/Kernel driver    : /p' | while IFS= read -r L; do log "$L"; done
        fi
      fi
    fi
  fi

  [[ "$debug" -eq 1 ]] && log "----"
done

# ---------------- Final Unique Summary ----------------
if [[ "$debug" -eq 1 ]]; then
echo "Unique VendorID:DeviceID combinations:"
fi

if ((${#uniq_vid_did[@]} == 0)); then
  echo "(none found)"
  exit
fi
for k in "${!uniq_vid_did[@]}"; do
  ven=$(echo "$k" | awk -F ':' '{print $1}')
  dev=$(echo "$k" | awk -F ':' '{print $2}')
  echo "\"ven_${ven}\"+\"dev_${dev}\""
done | sort -u
