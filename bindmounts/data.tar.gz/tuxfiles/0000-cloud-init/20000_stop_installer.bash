#!/bin/bash
###################################################################################
# 2000_stop_installer.bash
###################################################################################
# Stops Ubuntu Live's default Subiquity installer and displays a custom status image.
# Designed for cloud-init environments where a custom installation process replaces
# the standard Ubuntu installer.
#
# Operations performed:
#   1. Sources configuration variables from /dev/shm/variables.config
#   2. Stops the subiquity snap service to prevent default installer UI from launching
#   3. Calls helper script to display custom image/logo on physical console (tty0)
#
# Use case: Part of a custom Windows installation workflow running from Ubuntu Live
# environment. By stopping subiquity, the system remains available for scripted
# operations without user interaction with the standard Ubuntu installer.
#
# Dependencies:
#   - /dev/shm/variables.config must exist
#   - /dev/shm/Z0_show_image_per_script.bash helper script must be available
###################################################################################
# Variables in CAPITALS are loaded from ./variables.config.

# source variables from variables.config
source /dev/shm/variables.config

# Stop the subiquity installer snap to prevent the live installer from running.
echo -n "stopping subiquity snap..."
snap stop subiquity 1>/dev/null
echo "done"

# show an image on screen if an image <scriptname-withou-extension>.png exists
/dev/shm/Z0_show_image_per_script.bash
