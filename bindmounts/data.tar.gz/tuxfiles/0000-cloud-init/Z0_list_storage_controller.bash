#!/usr/bin/env bash
# Usage:
#   diskdevice=/dev/sda   ./disk_to_controller.sh
#   diskdevice=/dev/nvme0n1 ./disk_to_controller.sh
#
# Outputs:
#   - PCI address of the controller (e.g., 0000:00:13.0)
#   - lspci line with class, vendor/device name, and [vendor:device] IDs
#   - separate vendor and device IDs
diskdevice=$(./Z0_identify_target_block_device.bash)
debug=0

set -euo pipefail

# Require diskdevice in environment or as first arg
if [[ $# -ge 1 ]]; then
  diskdevice="$1"
fi
if [[ -z "${diskdevice:-}" ]]; then
  echo "ERROR: Please set diskdevice (e.g., diskdevice=/dev/sda) or pass it as the first argument." >&2
  exit 1
fi
if [[ ! -e "$diskdevice" ]]; then
  echo "ERROR: '$diskdevice' does not exist." >&2
  exit 1
fi

# Ensure required tools exist
for cmd in udevadm lspci realpath; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "ERROR: '$cmd' is required but not found in PATH." >&2
    exit 1
  fi
done

# Resolve the sysfs path for the block device
sys_path="$(udevadm info --query=path --name="$diskdevice" 2>/dev/null || true)"
if [[ -z "$sys_path" ]]; then
  echo "ERROR: Could not resolve sysfs path for $diskdevice via udevadm." >&2
  exit 1
fi
sys_abspath="/sys${sys_path}"

# Try to extract a PCI address using ID_PATH first (fast path)
id_path="$(udevadm info --query=all --name="$diskdevice" 2>/dev/null | grep -E '^E: ID_PATH=' | sed -E 's/^E: ID_PATH=//')"
pci_addr=""
if [[ -n "$id_path" ]]; then
  # Look for 'pci-0000:..:..:.' in the ID_PATH and extract the numeric address
  pci_addr="$(grep -oE 'pci-0000:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]' <<<"$id_path" | sed 's/^pci-//')"
fi

# Fallback: walk up sysfs parents to find the PCI device node
if [[ -z "$pci_addr" ]]; then
  # Start from the device node of the block device
  dev_link="$(realpath "$sys_abspath/device" 2>/dev/null || true)"
  if [[ -z "$dev_link" ]]; then
    echo "ERROR: Could not resolve '$sys_abspath/device' symlink." >&2
    exit 1
  fi

  # Walk up the tree until we find a directory that looks like a PCI function: 0000:BB:DD.F
  cur="$dev_link"
  found=""
  for _ in {1..12}; do
    base="$(basename "$cur")"
    if [[ "$base" =~ ^0000:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]]; then
      found="$base"
      break
    fi
    # Stop if we hit root
    parent="$(realpath -m "$cur/..")"
    if [[ "$parent" == "$cur" || "$parent" == "/" ]]; then
      break
    fi
    cur="$parent"
  done

  if [[ -n "$found" ]]; then
    pci_addr="$found"
  fi
fi

if [[ -z "$pci_addr" ]]; then
  echo "ERROR: Could not determine PCI controller address for $diskdevice." >&2
  echo "Hint: This can happen in virtualized environments (virtio/virtio-blk) or if the device is not PCI-backed." >&2
  exit 1
fi

# Query lspci for human-readable info and numeric IDs
lspci_line="$(lspci -s "$pci_addr" -nn 2>/dev/null || true)"
if [[ -z "$lspci_line" ]]; then
  echo "ERROR: lspci did not return information for PCI device '$pci_addr'." >&2
  exit 1
fi

# Extract vendor/device IDs inside square brackets [vvvv:dddd]
vnid="$(grep -oE '\[[0-9a-fA-F]{4}:[0-9a-fA-F]{4}\]' <<<"$lspci_line" | tr -d '[]')"
vendor_id="${vnid%%:*}"
device_id="${vnid##*:}"
if [[ "$debug" -eq 1 ]]; then
 echo "Disk device      : $diskdevice"
 echo "Controller (PCI) : $pci_addr"
 echo "Controller info  : $lspci_line"
 echo "Vendor ID        : $vendor_id"
 echo "Device ID        : $device_id"
fi
if [[ -n "$vendor_id" && -n "$device_id" ]]; then
  echo "\"dev_${vendor_id}\"+\"dev_${device_id}\""
fi

